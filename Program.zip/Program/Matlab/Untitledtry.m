
data=xlsread('newexpdata1.xlsx');
x3=data(:,1);
z3=data(:,2);
plot(x3,z3,'g*');