clc;clear
p=0:0.0001:0.03;
%angle2=linspace(0,2*pi,301);

fp1=150700*p.^3+15670*p.^2+178.4*p;%��ǻ1�쳤��
fp2=-2057000*p.^3+66030*p.^2-329.5*p;%��ǻ2�쳤��
fp3=-2057000*p.^3+66030*p.^2-329.5*p;%��ǻ3�쳤��

xip=fp1.^2+fp2.^2+fp3.^2-(fp1.*fp2)-(fp1.*fp3)-(fp2.*fp3);

angle1=(sqrt(xip))/7.13;%�����Ƕ�
L=100+(fp1+fp2+fp3)/3;%�����߳�

x=(L./angle1).*(1-cos(angle1));
%y=(L./angle1).*(1-cos(angle1));
%R=(L./angle1).*(1-cos(angle1));
%x=R.*cos(angle2);
%y=R.*sin(angle2);
y=x.*0;
z=(L./angle1).*sin(angle1)-100;

l=plot3(x,y,z,'r');%����켣

lineNum = 500;
%axis('equal','off',[-11,11,-11,11,-3,3]);
theta = linspace(0,2*pi,lineNum);
c = colormap(jet(lineNum));
for ii = 1:lineNum
    hGroup2(ii) = hgtransform('Parent',gca);
    hGroup2(ii).Matrix = makehgtform('zrotate',theta(ii));    
    lGroup2(ii) = copyobj(l,gca);
    lGroup2(ii).Color = c(ii,:);    
    lGroup2(ii).Parent = hGroup2(ii);
    drawnow
    if ii == 1 
        [A,map] = rgb2ind(frame2im(getframe(gcf)),256);
        imwrite(A,map,'2.gif','LoopCount',65535,'DelayTime',0);
    else if mod(ii,5) == 0
            [A,map] = rgb2ind(frame2im(getframe(gcf)),256);
            imwrite(A,map,'2.gif','WriteMode','append','DelayTime',0);
        end
    end
end

set(gcf,'color','white');